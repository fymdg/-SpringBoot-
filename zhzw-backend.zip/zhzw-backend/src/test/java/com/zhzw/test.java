package com.zhzw;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zhzw.mapper.UserMapper;
import com.zhzw.pojo.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class test {
    @Autowired
    private UserMapper userMapper;

    @Test
    public void test() {
        IPage<User> page = new Page(1, 2);
        IPage<User> userIPage = userMapper.selectPageByParams(page, "张三", "张三");
        System.out.println(userIPage.getPages());
        System.out.println(userIPage.getRecords());
    }
}
