package com.zhzw;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.zhzw.utils.JwtUtil;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JwtTest {
    //测试生成一个jwt的令牌token
    @Test
    public void testGenerateToken(){
        //创建一个map，存储一些数据，将它作为token的负载部分
        Map<String,Object> claims = new HashMap<>();
        claims.put("id",1);
        claims.put("username","admin");
        String token = JWT.create()
                .withClaim("user",claims)
                .withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60 * 60))
                .sign(Algorithm.HMAC256("secret"));
        System.out.println(token);
    }
    //测试验证一个jwt的令牌token
    @Test
    public void testVerifyToken(){
        String jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoxLCJ1c2VybmFtZSI6ImFkbWluIn0sImV4cCI6MTc2NjU2MzMzOX0.EzRTgBUFBEHDrgqTCOoyxX4ck43LzXVjz6Tpw6owCNk";
        JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256("secret")).build();
        DecodedJWT verify = jwtVerifier.verify(jwt);
        //获取负载部分
        Map<String, Object> user = verify.getClaim("user").asMap();
        System.out.println(user);
    }

    //使用工具类生成token令牌
    @Test
    public void testGenerateTokenByUtil(){
        Map<String,Object> claims = new HashMap<>();
        claims.put("id",1);
        claims.put("username","admin");
        String token = JwtUtil.genToken(claims);
        System.out.println(token);
    }
    //使用工具类验证token令牌
    @Test
    public void testVerifyTokenByUtil(){
        String jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGFpbXMiOnsiaWQiOjEsInVzZXJuYW1lIjoiYWRtaW4ifSwiZXhwIjoxNzY2NTY1MzA5fQ.zDXt0auNAmRnCyo8ap8zG4gY3yR2ZE4gGIpQbrDW12k";
        Map<String, Object> map = JwtUtil.parseToken(jwt);
        System.out.println(map);
    }
}
