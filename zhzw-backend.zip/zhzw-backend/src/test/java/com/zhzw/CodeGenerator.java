package com.zhzw;
import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.engine.VelocityTemplateEngine;

import java.util.Collections;

public class CodeGenerator {
    public static void main(String[] args) {
        // 1. 数据库配置（替换为你的数据库信息）
        String url = "jdbc:mysql://localhost:3306/zhzw?useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true";
        String username = "root";
        String password = "666666";
        String driver = "com.mysql.cj.jdbc.Driver";

        // 2. 代码生成配置
        FastAutoGenerator.create(url, username, password)
                // 全局配置
                .globalConfig(builder -> {
                    builder.author("djx") // 作者名
                            .outputDir(System.getProperty("user.dir") + "/src/main/java") // 代码输出目录（项目java目录）
                            .commentDate("yyyy-MM-dd") // 注释日期格式
                            .disableOpenDir() // 生成后不自动打开文件夹
                            .build();
                })
                // 包配置（指定代码生成到哪个包下）
                .packageConfig(builder -> {
                    builder.parent("com.zhzw") // 父包名（替换为你的项目父包）
                            .moduleName("") // 模块名（无需模块则留空）
                            .entity("pojo") // 实体类包名
                            .mapper("mapper") // Mapper接口包名
                            .service("service") // Service接口包名
                            .serviceImpl("service.impl") // Service实现类包名
                            .controller("controller") // Controller包名
                            .xml("mapper.xml") // Mapper.xml文件输出目录（默认resources下）
                            .pathInfo(Collections.singletonMap(OutputFile.xml, System.getProperty("user.dir") + "/src/main/resources/com/zhzw/mapper"))
                            .build();
                })
                // 策略配置（指定生成哪些表、生成规则）
                .strategyConfig(builder -> {
                    builder.addInclude("evaluate") // 要生成的数据库表名（多个表用逗号分隔）
                            .addTablePrefix("t_", "sys_") // 忽略表前缀（如t_user -> User实体）
                            // 实体类策略
                            .entityBuilder()
                            .enableLombok()
                            .enableTableFieldAnnotation() // 字段添加@TableField注解
                            .logicDeleteColumnName("reserve_status") // 逻辑删除字段（如有）
                            // Controller策略（生成RestController）
                            // 核心修改：忽略指定字段（填写数据库中的字段名，多个字段用逗号分隔）
                            .controllerBuilder()
                            .enableRestStyle() // 启用Rest风格（@RestController）
                            .enableHyphenStyle() // URL支持下划线转连字符（如/user-info）
                            // Mapper策略
                            .mapperBuilder()
                            .enableBaseResultMap() // 启用BaseResultMap（XML中生成结果映射）
                            .enableBaseColumnList() // 启用BaseColumnList（XML中生成查询字段列表）
                            .build();
                })
                // 模板引擎（使用Velocity）
                .templateEngine(new VelocityTemplateEngine())
                // 执行生成
                .execute();
    }

}
