package com.zhzw.controller;

import com.zhzw.pojo.ApplyDetailVO;
import com.zhzw.pojo.Result;
import com.zhzw.service.ApplyDVoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
@RequestMapping("/applyvo")
public class ApplyDVoController {
    @Autowired
    private ApplyDVoService applyDVoService;
    //根据用户的ID查询在线办件记录
    @GetMapping("/queryapplybyuserid")
    public Result queryApplyByUserId(Integer userId){
        List<ApplyDetailVO> applys=applyDVoService.selectApplyByUserId(userId);
        return Result.success(applys);
    }
}
