package com.zhzw.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.Item;
import com.zhzw.pojo.Result;
import com.zhzw.pojo.User;
import com.zhzw.service.IItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * 政务事项表 前端控制器
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@RestController
@RequestMapping("/item")
public class ItemController {
    @Autowired
    private IItemService itemService;
    @GetMapping ("/selectallitem")
    public Result selectAllItem(){
        List<Item> list = itemService.list();
        return Result.success(list);
    }
    //分页查询所有的事件
    @GetMapping("/allitempage")
    public Result selectAllItemPage(Integer pageNum,Integer pageSize,String itemName){
        IPage<Item> itemIPage = itemService.selectAllItemPage(pageNum, pageSize, itemName);
        return Result.success(itemIPage);
    }

}
