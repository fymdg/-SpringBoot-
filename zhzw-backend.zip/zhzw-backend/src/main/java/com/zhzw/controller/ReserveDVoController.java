package com.zhzw.controller;

import com.zhzw.pojo.ReserveDetailVO;
import com.zhzw.pojo.Result;
import com.zhzw.service.ReserveDVoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/reservevo")
public class ReserveDVoController {
    @Autowired
    private ReserveDVoService reserveDVoService;
    //根据用户ID查询预约记录
    @GetMapping("/selectbyuserid")
    public Result queryByUserId(Integer userId) {
        List<ReserveDetailVO> reservations = reserveDVoService.selectReservationByUserId(userId);
        return Result.success(reservations);
    }
}
