package com.zhzw.controller;

import com.zhzw.pojo.Apply;
import com.zhzw.pojo.ApplyDetailVO;
import com.zhzw.pojo.Result;
import com.zhzw.service.IApplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 在线办件表 前端控制器
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@RestController
@RequestMapping("/apply")
public class ApplyController {
    @Autowired
    private IApplyService applyService;

    @PostMapping("/addapply")
    public  Result addApply(@RequestBody Apply apply){
        applyService.save(apply);
        return Result.success("在线办件成功");
    }
    //根据Id删除一条在线办理记录
    @DeleteMapping("/deletebyid")
    public Result deleteApplyById(Integer applyId){
        if(applyService.deleteApplyById(applyId))
            return Result.success("删除成功");
        else
            return Result.error("删除失败");
    }


}
