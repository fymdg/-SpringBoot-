package com.zhzw.controller;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.User;
import com.zhzw.service.UserService;
import com.zhzw.pojo.Result;
import com.zhzw.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private RedisTemplate redisTemplate;



    @GetMapping("/login")
    public Result login(String cardId,String password){
        User user = userService.getUserByIdAndPwd(cardId,password);
        if(user != null){
            //生成token令牌,负载是用户的相关信息
            Map<String,Object> claims = new HashMap<>();
            claims.put("phone",user.getPhone());
            claims.put("realName",user.getRealName());
            claims.put("idCard",user.getIdCard());
            claims.put("userType",user.getUserType());
            String token = JwtUtil.genToken(claims);
            return Result.success(token);
        }else {
            return Result.error("用户名或密码错误！");
        }
    }
    //解析token返回用户名和电话的方法
    @GetMapping("/usermessage")
    public Result getUsername(@RequestHeader("Authorization") String  authorization){
        Map<String, Object> userMessage = JwtUtil.parseToken(authorization);
        User user=new User();
        String realName = userMessage.get("realName") == null ? "" : userMessage.get("realName").toString();
        String phone = userMessage.get("phone") == null ? "" : userMessage.get("phone").toString();
        String idCard = userMessage.get("idCard") == null ? "" : userMessage.get("idCard").toString();
        Object userTypeObj = userMessage.get("userType");
        Integer userType;
        if (userTypeObj == null) {
            userType = 1; // 默认值
        } else if (userTypeObj instanceof Integer) {
            userType = (Integer) userTypeObj;
        } else if (userTypeObj instanceof Number) {
            // 如果是其他数值类型（如Long），转换为Integer
            userType = ((Number) userTypeObj).intValue();
        } else {
            // 如果是字符串或其他类型，尝试转换
            try {
                userType = Integer.parseInt(userTypeObj.toString());
            } catch (NumberFormatException e) {
                userType = 1; // 转换失败时使用默认值
            }
        }
        user.setPhone(phone);
        user.setRealName(realName);
        user.setIdCard(idCard);
        user.setUserType( userType);
        return Result.success(user);
    }
    //注册一个新用户
    @PostMapping("/register")
    public Result addUser(@RequestBody User user){
        userService.save(user);
        return Result.success();
    }
    //根据用户的姓名和电话查询id
    @GetMapping("/getid")
    public Result getIdByPhoneAndName(String phone, String name){
        Integer id = userService.selectIdByPhoneAndName(phone,name);
        if(id != null){
            return Result.success(id);
        }else{
            return Result.error("没有查询结果");
        }
    }
    //根据手机号修改密码
    @PutMapping("/updatepassword")
    public Result updatePassword(@RequestParam String phone,@RequestParam String password){
        if(userService.update(new UpdateWrapper<User>().eq("phone",phone).set("password",password)))
            return Result.success();
        else
            return Result.error("修改密码失败");


    }
    //分页查询所有的用户
    @GetMapping("/alluserpage")
    public Result selectAllUserPage(Integer pageNum,Integer pageSize,String userName){
        IPage<User> userIPage = userService.selectAllUserPage(pageNum, pageSize, userName);
        return Result.success(userIPage);
    }

    //根据phone修改用户信息
    @PutMapping("/edituserdata")
    public Result editUserData(@RequestBody User user){
        if(userService.updateUserById(user)) {
            return Result.success();
        }
        return Result.error("修改信息失败");
    }

    //根据用户ID删除用户的同时删除相关的问答和和评论记录
    @DeleteMapping("/removeuserwithdata")
    public Result deleteUserWithRelatedData(Integer userId) {
        if(userService.deleteUserWithRelatedData(userId)){
            return Result.success();
        }else {
            return Result.error("删除失败");
        }
    }


}
