package com.zhzw.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.Evaluate;
import com.zhzw.pojo.Item;
import com.zhzw.pojo.Result;
import com.zhzw.service.IEvaluateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 服务评价表 前端控制器
 * </p>
 *
 * @author djx
 * @since 2026-01-09
 */
@RestController
@RequestMapping("/evaluate")
public class EvaluateController {
    @Autowired
    private IEvaluateService evaluateService;
    //查询所有评论
    @GetMapping("/selectall")
    public Result selectAllReservation(){
        List<Evaluate> list = evaluateService.list();
        return Result.success(list);
    }
    //通过id删除一条评论
    @DeleteMapping("/deletebyid")
    public Result deleteById(Integer id){
        if(evaluateService.deleteEvaluateById(id)>0) {
            return Result.success();
        }else{
            return Result.error("删除失败");
        }
    }
    //添加一条评论
    @PostMapping("/add")
    public Result insertEvaluate(@RequestBody Evaluate evaluate){
        if(evaluateService.save(evaluate)){
        return Result.success();
        }else{
            return Result.error("添加评论成功");
        }
    }
    //修改评论内容
    @PutMapping("/update")
    public Result updateEvaluate(@RequestBody Evaluate evaluate){
        if(evaluateService.updateById(evaluate)){
            return Result.success();
        }else{
            return Result.error("修改失败");
        }
    }
    //分页查询所有的评论
    @GetMapping("/allevaluatepage")
    public Result selectAllEvaluatePage(Integer pageNum,Integer pageSize,String deptName){
        IPage<Evaluate> evaluateIPage = evaluateService.selectAllEvaluatePage(pageNum, pageSize, deptName);
        return Result.success(evaluateIPage);
    }

}
