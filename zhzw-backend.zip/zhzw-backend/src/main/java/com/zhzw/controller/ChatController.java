package com.zhzw.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.Item;
import com.zhzw.pojo.QaRecord;
import com.zhzw.pojo.Result;
import com.zhzw.service.ChatService;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.AbstractChatMemoryAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/ai/chat")
public class ChatController {
    @Autowired
    private ChatService chatService;
    @Autowired
    private ChatClient chatClient;

    //对话1
    @RequestMapping("/one")
    public String chat1(String question){
        return chatClient.prompt().user(question).call().content();
    }
    //对话2
    @RequestMapping( value = "/two",produces = "text/html;charset=utf-8")
    public Flux<String> chat2(String question){
        List<String> lists = new ArrayList<>();
        return chatClient.prompt()
                .user(question)
                .stream()
                .content();
    }
    //保存一次对话
    @PostMapping("/saveaq")
    public Result saveQaRecord(@RequestBody QaRecord record){
        chatService.save(record);
        return Result.success("添加对话记录成功");
    }
    //分页查询所有ai对话
    @GetMapping("/allrecordpage")
    public Result selectAllRecordPage(Integer pageNum,Integer pageSize){
        IPage<QaRecord> recordIPage = chatService.selectAllRecordPage(pageNum, pageSize);
        return Result.success(recordIPage);
    }
}
