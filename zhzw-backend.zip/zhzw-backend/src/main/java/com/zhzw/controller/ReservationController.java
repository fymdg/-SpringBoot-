package com.zhzw.controller;

import com.zhzw.pojo.Reservation;
import com.zhzw.pojo.ReserveDetailVO;
import com.zhzw.pojo.Result;
import com.zhzw.service.IReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 线下服务预约表 前端控制器
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@RestController
@RequestMapping("/reservation")
public class ReservationController {
    @Autowired
    private IReservationService reservationService;
    //添加预约
    @PostMapping("/addreservation")
    public Result addReservation(@RequestBody Reservation reservation) {
        reservationService.save(reservation);
        return Result.success("预约成功");
    }
    //根据ID删除一条预约记录
    @DeleteMapping("/deletebyid")
    public Result deleteReservationById(Integer reserveId){
        if(reservationService.deleteByReservationId(reserveId))
        return Result.success("删除成功");
        else
            return Result.error("删除失败");
    }


}
