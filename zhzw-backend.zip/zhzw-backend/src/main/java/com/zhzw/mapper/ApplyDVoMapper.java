package com.zhzw.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhzw.pojo.ApplyDetailVO;

import java.util.List;

public interface ApplyDVoMapper extends BaseMapper<ApplyDetailVO> {
    List<ApplyDetailVO> selectApplyByUserId(Integer userId);
}
