package com.zhzw.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Update;

public interface UserMapper extends BaseMapper<User> {
    //分页查询用户
    IPage<User> selectPageByParams(IPage<User> page, String username, String nickname);
    //根据电话和名字查询id
    Integer selectIdByPhoneAndName(String phone, String name);
    //分页查询
    IPage<User> selectAllUserPage(IPage page,String userName);
    //更新用户信息
    int updateUserById(User user);

    @Delete("delete  from user where  id=#{userId} ")
    int deleteUserById(Integer userId);
}
