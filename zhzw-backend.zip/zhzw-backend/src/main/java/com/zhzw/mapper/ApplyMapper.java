package com.zhzw.mapper;

import com.zhzw.pojo.Apply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhzw.pojo.ApplyDetailVO;
import com.zhzw.pojo.ReserveDetailVO;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

/**
 * <p>
 * 在线办件表 Mapper 接口
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
public interface ApplyMapper extends BaseMapper<Apply> {


    @Delete("DELETE FROM apply WHERE id = #{applyId}")
    int deleteApplyById( Integer applyId);

}
