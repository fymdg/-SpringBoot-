package com.zhzw.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.QaRecord;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.Delete;


public interface ChatMapper extends BaseMapper<QaRecord> {
    IPage<QaRecord> selectAllRecordPage(IPage page);

    @Delete("DELETE FROM `qa_record` WHERE user_idf = #{userId}")
    int deleteQaByUserId(Integer userId);
}
