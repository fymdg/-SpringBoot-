package com.zhzw.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.Evaluate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhzw.pojo.Item;
import org.apache.ibatis.annotations.Delete;

/**
 * <p>
 * 服务评价表 Mapper 接口
 * </p>
 *
 * @author djx
 * @since 2026-01-09
 */
public interface EvaluateMapper extends BaseMapper<Evaluate> {
    IPage<Evaluate> selectAllEvaluatePage(IPage page, String deptName);

    @Delete("DELETE FROM `evaluate` WHERE user_id = #{userId}")
    int deleteCommentByUserId(Integer userId);

}
