package com.zhzw.mapper;

import com.zhzw.pojo.Reservation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhzw.pojo.ReserveDetailVO;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

/**
 * <p>
 * 线下服务预约表 Mapper 接口
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
public interface ReservationMapper extends BaseMapper<Reservation> {
    @Delete("delete from reservation where id=#{reserveId}")
    int deleteByReservationId(Integer reserveId);



}
