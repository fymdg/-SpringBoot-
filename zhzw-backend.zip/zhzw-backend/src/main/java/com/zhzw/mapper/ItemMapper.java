package com.zhzw.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.Item;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhzw.pojo.User;

/**
 * <p>
 * 政务事项表 Mapper 接口
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
public interface ItemMapper extends BaseMapper<Item> {
    IPage<Item> selectAllItemPage(IPage page, String itemName);

}
