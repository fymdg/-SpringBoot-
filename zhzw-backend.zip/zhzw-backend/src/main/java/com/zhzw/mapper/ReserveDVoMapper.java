package com.zhzw.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhzw.pojo.ReserveDetailVO;

import java.util.List;

public interface ReserveDVoMapper extends BaseMapper<ReserveDetailVO> {
    List<ReserveDetailVO> selectReservationByUserId(Integer userId);
}
