package com.zhzw.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhzw.mapper.ApplyDVoMapper;
import com.zhzw.pojo.ApplyDetailVO;
import com.zhzw.service.ApplyDVoService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ApplyDVoServiceImpl extends ServiceImpl<ApplyDVoMapper, ApplyDetailVO> implements ApplyDVoService {
    @Override
    public List<ApplyDetailVO> selectApplyByUserId(Integer userId) {
        return baseMapper.selectApplyByUserId(userId);
    }
}
