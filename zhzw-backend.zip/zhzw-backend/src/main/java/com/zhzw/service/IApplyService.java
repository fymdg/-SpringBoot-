package com.zhzw.service;

import com.zhzw.pojo.Apply;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.ApplyDetailVO;

import java.util.List;

/**
 * <p>
 * 在线办件表 服务类
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
public interface IApplyService extends IService<Apply> {
     boolean deleteApplyById(Integer applyId);

}
