package com.zhzw.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.User;

public interface UserService extends IService<User> {
    //根据用户名和密码查询用户的功能
    User getUserByIdAndPwd(String cardId,String password);
    Integer selectIdByPhoneAndName(String phone, String name);
    //分页查询用户
    IPage<User> selectAllUserPage(Integer pageNum, Integer pageSize, String userName);
     boolean deleteUserWithRelatedData(Integer userId);
    boolean updateUserById(User user);
}
