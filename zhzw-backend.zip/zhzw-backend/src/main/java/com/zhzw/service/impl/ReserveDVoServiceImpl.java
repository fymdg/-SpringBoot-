package com.zhzw.service.impl;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhzw.mapper.ReserveDVoMapper;
import com.zhzw.pojo.ReserveDetailVO;
import com.zhzw.service.ReserveDVoService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ReserveDVoServiceImpl extends ServiceImpl<ReserveDVoMapper,ReserveDetailVO> implements ReserveDVoService {
    @Override
    public List<ReserveDetailVO> selectReservationByUserId(Integer userId) {
        return baseMapper.selectReservationByUserId(userId);
    }
}
