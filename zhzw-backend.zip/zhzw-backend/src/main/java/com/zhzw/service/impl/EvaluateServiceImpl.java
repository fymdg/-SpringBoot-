package com.zhzw.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zhzw.pojo.Evaluate;
import com.zhzw.mapper.EvaluateMapper;
import com.zhzw.service.IEvaluateService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务评价表 服务实现类
 * </p>
 *
 * @author djx
 * @since 2026-01-09
 */
@Service
public class EvaluateServiceImpl extends ServiceImpl<EvaluateMapper, Evaluate> implements IEvaluateService {
    public Integer deleteEvaluateById(Integer id){
        return baseMapper.deleteById(id);
    }
    //评价信息分页

    @Override
    public IPage<Evaluate> selectAllEvaluatePage(Integer pageNum, Integer pageSize, String deptName) {
        IPage<Evaluate> page = new Page<>(pageNum, pageSize);
        return baseMapper.selectAllEvaluatePage(page, deptName);
    }

    @Override
    public int deleteCommentByUserId(Integer userId) {
        return baseMapper.deleteCommentByUserId(userId);
    }
}
