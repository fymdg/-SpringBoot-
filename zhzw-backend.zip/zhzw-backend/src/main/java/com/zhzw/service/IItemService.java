package com.zhzw.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.Item;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.User;

/**
 * <p>
 * 政务事项表 服务类
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
public interface IItemService extends IService<Item> {
    IPage<Item> selectAllItemPage(Integer pageNum, Integer pageSize, String itemName);

}
