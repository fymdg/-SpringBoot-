package com.zhzw.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.zhzw.pojo.Evaluate;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.Item;

/**
 * <p>
 * 服务评价表 服务类
 * </p>
 *
 * @author djx
 * @since 2026-01-09
 */
public interface IEvaluateService extends IService<Evaluate> {
     Integer deleteEvaluateById(Integer id);
     IPage<Evaluate> selectAllEvaluatePage(Integer pageNum, Integer pageSize, String deptName);

     int deleteCommentByUserId(Integer userId);

}
