package com.zhzw.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.ApplyDetailVO;

import java.util.List;

public interface ApplyDVoService extends IService<ApplyDetailVO> {
    List<ApplyDetailVO> selectApplyByUserId(Integer userId);
}
