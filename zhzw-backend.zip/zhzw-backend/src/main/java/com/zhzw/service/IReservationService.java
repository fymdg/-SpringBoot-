package com.zhzw.service;

import com.zhzw.pojo.Reservation;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.ReserveDetailVO;

import java.util.List;

/**
 * <p>
 * 线下服务预约表 服务类
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
public interface IReservationService extends IService<Reservation> {
    boolean deleteByReservationId(Integer reserveId);


}
