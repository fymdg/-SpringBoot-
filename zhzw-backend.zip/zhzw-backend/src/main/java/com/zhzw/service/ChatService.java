package com.zhzw.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.Item;
import com.zhzw.pojo.QaRecord;

public interface ChatService extends IService<QaRecord> {
    IPage<QaRecord> selectAllRecordPage(Integer pageNum, Integer pageSize);
    int deleteQaByUserId(Integer userId);
}
