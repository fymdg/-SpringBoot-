package com.zhzw.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.zhzw.pojo.Reservation;
import com.zhzw.mapper.ReservationMapper;
import com.zhzw.pojo.ReserveDetailVO;
import com.zhzw.pojo.User;
import com.zhzw.service.IReservationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 线下服务预约表 服务实现类
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@Service
public class ReservationServiceImpl extends ServiceImpl<ReservationMapper, Reservation> implements IReservationService {
    @Override
    public boolean deleteByReservationId(Integer reserveId) {
        return baseMapper.deleteByReservationId(reserveId) > 0;
    }
}
