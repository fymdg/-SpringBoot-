package com.zhzw.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zhzw.pojo.Item;
import com.zhzw.mapper.ItemMapper;
import com.zhzw.service.IItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 政务事项表 服务实现类
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@Service
public class ItemServiceImpl extends ServiceImpl<ItemMapper, Item> implements IItemService {
    @Override
    public IPage<Item> selectAllItemPage(Integer pageNum, Integer pageSize, String itemName) {
        IPage<Item> page = new Page<>(pageNum, pageSize);
        return baseMapper.selectAllItemPage(page,itemName);
    }
}
