package com.zhzw.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhzw.mapper.ChatMapper;
import com.zhzw.pojo.QaRecord;
import com.zhzw.service.ChatService;
import org.springframework.stereotype.Service;

@Service
public class ChatServiceImpl extends ServiceImpl<ChatMapper, QaRecord> implements ChatService {
    @Override
    public IPage<QaRecord> selectAllRecordPage(Integer pageNum, Integer pageSize) {
        IPage<QaRecord> page = new Page<>(pageNum, pageSize);
        return baseMapper.selectAllRecordPage(page);
    }

    @Override
    public int deleteQaByUserId(Integer userId) {
        return baseMapper.deleteQaByUserId(userId);
    }
}
