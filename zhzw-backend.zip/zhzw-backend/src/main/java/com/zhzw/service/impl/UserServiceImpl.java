package com.zhzw.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhzw.mapper.UserMapper;
import com.zhzw.pojo.User;
import com.zhzw.service.ChatService;
import com.zhzw.service.IEvaluateService;
import com.zhzw.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    @Autowired
    private ChatService chatService;
    @Autowired
    private IEvaluateService evaluateService;
    @Override
    public User getUserByIdAndPwd(String cardId, String password) {
        QueryWrapper<User> qw = new QueryWrapper();
        qw.or(wrapper -> wrapper
                        .eq("id_card", cardId)
                        .eq("password", password)
                        .or() // 分组内的 OR
                        .eq("phone", cardId)
                        .eq("password", password)
                )
                .eq("status", 1);
        return baseMapper.selectOne(qw);
    }

    @Override
    public Integer selectIdByPhoneAndName(String phone, String name) {
        return baseMapper.selectIdByPhoneAndName(phone,name);
    }
//用户的分页查询
    @Override
    public IPage<User> selectAllUserPage(Integer pageNum, Integer pageSize, String userName) {
        IPage<User> Page = new Page<>(pageNum, pageSize);
        return baseMapper.selectAllUserPage(Page,userName);
    }

    @Transactional(rollbackFor = Exception.class) // 事务仍生效，覆盖所有调用链
    public boolean deleteUserWithRelatedData(Integer userId) {
        // 1. 调用QaService删除用户问答（复用问答业务逻辑）
        chatService.deleteQaByUserId(userId);

        // 2. 调用CommentService删除用户评论（复用评论业务逻辑）
        evaluateService.deleteCommentByUserId(userId);

        // 3. 删除用户
        int affectedRows =baseMapper.deleteUserById(userId);

        return affectedRows > 0;
    }

    @Override
    public boolean updateUserById(User user) {
        return baseMapper.updateUserById(user)>0;
    }
}
