package com.zhzw.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zhzw.pojo.ReserveDetailVO;

import java.util.List;

public interface ReserveDVoService extends IService<ReserveDetailVO> {
    List<ReserveDetailVO> selectReservationByUserId(Integer userId);
}
