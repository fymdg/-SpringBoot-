package com.zhzw.service.impl;

import com.zhzw.pojo.Apply;
import com.zhzw.mapper.ApplyMapper;
import com.zhzw.pojo.ApplyDetailVO;
import com.zhzw.service.IApplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 在线办件表 服务实现类
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@Service
public class ApplyServiceImpl extends ServiceImpl<ApplyMapper, Apply> implements IApplyService {
    @Override
    public boolean deleteApplyById(Integer applyId) {
        return baseMapper.deleteApplyById(applyId)>0;
    }
}
