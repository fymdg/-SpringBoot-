package com.zhzw.config;

import com.zhzw.utils.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class HandlerInterceptor implements org.springframework.web.servlet.HandlerInterceptor {
    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getHeader("Authorization");
        try {
            token = redisTemplate.opsForValue().get(token).toString();
            if(token == null){
                throw new RuntimeException("token已过期！");
            }
            Map<String, Object> map = JwtUtil.parseToken(token);
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
        return true;
    }
}
