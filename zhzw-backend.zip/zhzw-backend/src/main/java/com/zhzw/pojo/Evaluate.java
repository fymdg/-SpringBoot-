package com.zhzw.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 服务评价表
 * </p>
 *
 * @author djx
 * @since 2026-01-09
 */
@Getter
@Setter
@TableName("evaluate")
public class Evaluate implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评价ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 评价用户ID（关联用户表主键）
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 服务事项
     */
    @TableField("service_item")
    private String serviceItem;

    /**
     * 办理机构
     */
    @TableField("dept_name")
    private String deptName;

    /**
     * 1-5星评分
     */
    @TableField("star")
    private Byte star;

    /**
     * 评价内容（可选）
     */
    @TableField("content")
    private String content;

    /**
     * 评论时间（默认当前时间）
     */
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss", // 匹配前端的时间格式
            timezone = "GMT+8" // 东八区（北京时间），避免时区偏差
    )
    @TableField("evaluate_time")
    private LocalDateTime evaluateTime;

    /**
     * 标签组（JSON数组存储，如["可以全程网上办理","服务热情效率高"]）
     */
    @TableField("tags")
    private String tags;
}
