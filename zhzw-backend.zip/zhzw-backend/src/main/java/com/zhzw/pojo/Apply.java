package com.zhzw.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 在线办件表
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@Getter
@Setter
@TableName("apply")
public class Apply implements Serializable {

    private static final long serialVersionUID = 1L;


    /**
     * 办件编号（YYYYMMDD+8位随机数）
     */
    @TableField("apply_no")
    private String applyNo;

    /**
     * 办理用户ID（外键）
     */
    @TableField("user_idf")
    private Long userIdf;

    /**
     * 办理事项ID（外键）
     */
    @TableField("item_idf")
    private Long itemIdf;

    /**
     * 0-草稿，1-待审核，2-审核通过，3-办结，4-驳回
     */
    @TableField("apply_status")
    private Byte applyStatus;

    /**
     * 提交时间（草稿无值）
     */
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss", // 匹配前端的时间格式
            timezone = "GMT+8" // 东八区（北京时间），避免时区偏差
    )
    @TableField("apply_time")
    private LocalDateTime applyTime;


    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss", // 匹配前端的时间格式
            timezone = "GMT+8" // 东八区（北京时间），避免时区偏差
    )
    @TableField("finish_time")
    private LocalDateTime finishTime;
}
