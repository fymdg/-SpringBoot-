package com.zhzw.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 政务事项表
 * </p>
 *
 * @author djx
 * @since 2026-01-08
 */
@Getter
@Setter
@TableName("item")
public class Item implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    /**
     * 政务统一事项编码
     */
    @TableField("item_code")
    private String itemCode;

    /**
     * 事项名称（如个人社保缴费）
     */
    @TableField("item_name")
    private String itemName;

    /**
     * 1-个人服务，2-法人服务
     */
    @TableField("item_type")
    private Byte itemType;

    /**
     * 1-全程网办，2-仅线下办，3-网办+线下核验
     */
    @TableField("handle_type")
    private Byte handleType;

    /**
     * 0-暂停办理，1-正常办理
     */
    @TableField("status")
    private Byte status;
}
