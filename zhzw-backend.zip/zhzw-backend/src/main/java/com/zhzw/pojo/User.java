package com.zhzw.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class User {
    private Integer id;
    private String realName;
//    @JsonIgnore
    private String password;
    private String idCard;
    private String phone;
    private Integer userType;
}
