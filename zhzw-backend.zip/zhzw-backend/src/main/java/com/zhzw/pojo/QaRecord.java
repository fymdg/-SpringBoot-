package com.zhzw.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;
@Data
@TableName("qa_record")
public class QaRecord {
    private Integer userIdf;
    private String question;
    private String answer;
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss", // 匹配前端的时间格式
            timezone = "GMT+8" // 东八区（北京时间），避免时区偏差
    )
    private Date createTime;
}
