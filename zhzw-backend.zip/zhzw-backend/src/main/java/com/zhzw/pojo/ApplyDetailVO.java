package com.zhzw.pojo;

import lombok.Data;
import java.time.LocalDateTime;

/**
 * 办件详情VO（接收apply+user+item三表联查结果）
 */
@Data
public class ApplyDetailVO {
    // 办件表字段
    private Long applyId;         // 办件ID（对应a.id AS apply_id）
    private String applyNo;       // 办件编号
    private Integer applyStatus;  //0-草稿，1-待审核，2-审核通过，3-办结，4-驳回
    private LocalDateTime applyTime;  // 提交时间
    private LocalDateTime finishTime; // 办结时间（仅状态3有值）

    // 事项表字段
    private String itemName;      // 事项名称
    private Integer handleType;   // 办理方式
}