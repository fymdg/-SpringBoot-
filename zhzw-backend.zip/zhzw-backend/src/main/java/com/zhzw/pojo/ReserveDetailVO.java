package com.zhzw.pojo;

import lombok.Data;
import java.time.LocalDate;

/**
 * 预约详情VO（接收四表联查结果）
 */
@Data
public class ReserveDetailVO {
    // 预约表字段（对应SQL别名reserve_id）
    private Long reserveId;        // 预约ID（对应r.id AS reserve_id）
    private String reserveNo;      // 预约编号
    private LocalDate reserveDate; // 预约日期（数据库date类型，对应LocalDate）
    private String reserveTime;    // 预约时段（如10:00-10:30）
    private Integer reserveStatus; // 预约状态（0-已确认，1-已完成，2-已取消）

    // 用户表字段
    private String userName;       // 用户名（对应u.real_name AS user_name）
    private String userPhone;      // 用户手机号（对应u.phone AS user_phone）
    // 事项表字段
    private String itemName;       // 事项名称
    // 大厅表字段
    private String hallName;       // 大厅名称
}