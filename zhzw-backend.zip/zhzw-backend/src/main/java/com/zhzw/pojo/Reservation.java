package com.zhzw.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class Reservation {
    private String reserveNo;
    private Integer userIdf;
    private Integer itemIdf;
    private Integer hallIdf;
    @JsonFormat(
            pattern = "yyyy-MM-dd"
    )
    private Date reserveDate;
    private String reserveTime;
}
