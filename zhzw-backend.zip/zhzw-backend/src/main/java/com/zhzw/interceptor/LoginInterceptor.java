package com.zhzw.interceptor;

import com.zhzw.utils.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
@Component
public class LoginInterceptor implements HandlerInterceptor {
    //拦截方法

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //1 获取请求头Authorization的值
        String token = request.getHeader("Authorization");
        //2 如果它不存在抛出异常
        try {
            if(token == null){
                throw new RuntimeException("当前用户未登录");
            }
            //3 如果存在，验证token，验证通过放行
            JwtUtil.parseToken(token);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            //更改响应状态码为401，并且返回false
            response.setStatus(401);
            return false;
        }
    }
}
